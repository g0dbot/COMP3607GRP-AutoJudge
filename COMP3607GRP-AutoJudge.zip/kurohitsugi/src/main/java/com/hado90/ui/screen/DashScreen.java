package com.hado90.ui.screen;

import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.*;
import java.io.File;
import java.util.List;
import com.hado90.config.style.Style;

public class DashScreen extends Screen {
    private String studentBulkFilePath;
    private String testBulkFilePath;
    private String outputFilePath;

    private int gapHeight;
    private int gapWidth;

    private Color btnColor;
    private int btnBorderRadius;

    public DashScreen(Style configStyle, String studentBulkFilePath, String testBulkFilePath, String outputFilePath) {
        super(configStyle);
        this.studentBulkFilePath = studentBulkFilePath;
        this.testBulkFilePath = testBulkFilePath;
        this.outputFilePath = outputFilePath;
    }

    @Override
    protected void addContent(JPanel contentPanel) {
        contentPanel.setLayout(new BorderLayout());

        this.gapHeight = Integer.parseInt(Style.getConfigValue("SIZE_XS1"));
        this.gapWidth = Integer.parseInt(Style.getConfigValue("SIZE_XS1"));
        this.btnColor = decodeColor(Style.getConfigValue("BG_SECONDARY_COLOR"));
        this.btnBorderRadius = Integer.parseInt(Style.getConfigValue("SIZE_M2"));

        // Button Panel with FlowLayout for spreading across the width
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 4, gapWidth, gapHeight)); // 1 row, 4 buttons

        JButton studentButton = createDragDropButton("Student Submissions Compressed", btnColor);
        JButton testButton = createDragDropButton("Test Compressed File Path", btnColor);
        JButton outputButton = createDragDropButton("Output File Path", btnColor);
        JButton judgeButton = createJudgeButton();

        // Add buttons to the panel
        buttonPanel.add(studentButton);
        buttonPanel.add(testButton);
        buttonPanel.add(outputButton);

        contentPanel.add(buttonPanel, BorderLayout.NORTH); // Add to the top (NORTH) of the layout
    }

    private JButton createDragDropButton(String type, Color btnColor) {
        JButton button = new JButton("Drag or Select " + type);

        button.setPreferredSize(new Dimension(150, 40));
        button.setBackground(btnColor);
        button.setFont(new Font("Arial", Font.PLAIN, 20));
        button.setForeground(decodeColor(Style.getConfigValue("TEXT_MAIN_COLOR")));

        new DropTarget(button, DnDConstants.ACTION_COPY, new DropTargetAdapter() {
            @Override
            public void drop(DropTargetDropEvent event) {
                try {
                    event.acceptDrop(DnDConstants.ACTION_COPY);
                    @SuppressWarnings("unchecked")
                    List<File> droppedFiles = (List<File>) event.getTransferable()
                            .getTransferData(DataFlavor.javaFileListFlavor);
                    for (File file : droppedFiles) {
                        if (file.isDirectory()) {
                            updatePathAndButton(type, file.getAbsolutePath(), button);
                        } else {
                            JOptionPane.showMessageDialog(button, "Only folders are allowed.");
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(decodeColor(Style.getConfigValue("BG_SECONDARY_COLOR")));
                button.setForeground(Color.WHITE);
                button.setFont(new Font("Arial", Font.BOLD, 22));
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(btnColor);
                button.setFont(new Font("Arial", Font.PLAIN, 20));
                button.setForeground(decodeColor(Style.getConfigValue("TEXT_MAIN_COLOR")));
            }
        });

        button.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            int returnVal = fileChooser.showOpenDialog(button);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                updatePathAndButton(type, selectedFile.getAbsolutePath(), button);
            }
        });

        return button;
    }

    private void updatePathAndButton(String type, String newPath, JButton button) {
        if (isValidDirectory(newPath)) {
            switch (type) {
                case "Student Bulk File Path":
                    studentBulkFilePath = newPath;
                    break;
                case "Test Bulk File Path":
                    testBulkFilePath = newPath;
                    break;
                case "Output File Path":
                    outputFilePath = newPath;
                    break;
            }
            button.setText("Path set: " + newPath);
            button.setBackground(Color.GREEN);
        } else {
            JOptionPane.showMessageDialog(button, "Invalid folder. Please select a valid directory.");
            button.setBackground(Color.RED);
        }
    }

    private boolean isValidDirectory(String path) {
        File file = new File(path);
        return file.exists() && file.isDirectory();
    }

    private JButton createJudgeButton() {
        JButton judgeButton = new JButton("JUDGE");
        judgeButton.setPreferredSize(new Dimension(150, 40));
        judgeButton.setBackground(decodeColor(Style.getConfigValue("EMO_COLOR_POS_SHADE_MAIN")));
        judgeButton.setFont(new Font("Arial", Font.PLAIN, 20));
        judgeButton.setForeground(decodeColor(Style.getConfigValue("TEXT_MAIN_COLOR")));

        // Hover effects for the button
        judgeButton.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                judgeButton.setBackground(decodeColor(Style.getConfigValue("BG_SECONDARY_COLOR")));
                judgeButton.setForeground(Color.WHITE);
                judgeButton.setFont(new Font("Arial", Font.BOLD, 22));
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                judgeButton.setBackground(decodeColor(Style.getConfigValue("EMO_COLOR_POS_SHADE_MAIN")));
                judgeButton.setFont(new Font("Arial", Font.PLAIN, 20));
                judgeButton.setForeground(decodeColor(Style.getConfigValue("TEXT_MAIN_COLOR")));
            }
        });

        // ActionListener to navigate to the Judge screen
        judgeButton.addActionListener(e -> {
            this.close();
        });

        return judgeButton;
    }

    @Override
    public void close() {
        super.close(); // Close the current screen window
        JudgeScreen judgeScreen = new JudgeScreen(configStyle, studentBulkFilePath, testBulkFilePath, outputFilePath); // Pass
                                                                                                                       // the
                                                                                                                       // correct
                                                                                                                       // configStyle
        judgeScreen.display();
    }
}
