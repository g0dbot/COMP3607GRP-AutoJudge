package com.hado90;

import javax.swing.SwingUtilities;

import com.hado90.config.style.Style;
import com.hado90.fileMgt.FileManager;
import com.hado90.judge.JavaJudge;
import com.hado90.judge.Judge;
import com.hado90.judge.compiler.JavaCompilerUtil;
import com.hado90.judge.testRunner.JavaTestRunner;
import com.hado90.pdfGenerator.PDFGenerator;
import com.hado90.submissionMgt.SubmissionManager;
import com.hado90.ui.screen.DashScreen;
import com.hado90.ui.screen.Screen;
import com.hado90.ui.SplashScreen;

public class Kurohitsugi {
    public static void main(String[] args) throws Exception {

        //ALL SERVICES AND MANAGERS
        String[] ACCEPTED_TYPES = {"zip"};

        final FileManager FILE_MANAGER;
        final SubmissionManager SUBMISSION_MANAGER;
        final JavaCompilerUtil JAVA_COMPILER_UTIL;
        final Judge JAVA_JUDGE;
        final JavaTestRunner JAVA_TEST_RUNNER;
        final PDFGenerator PDF_GENERATOR;

        //load style config
        Style configStyle = new Style();
        configStyle.loadConfig("style.json");
        
        //splash screen loader
        SplashScreen splashScreen = new SplashScreen();
        splashScreen.showSplashScreen();        

        try {
            long startTime = System.currentTimeMillis();
            
            FILE_MANAGER = new FileManager(ACCEPTED_TYPES);
            splashScreen.updateSplashLoaderProgress(10);
            
            SUBMISSION_MANAGER = new SubmissionManager();
            splashScreen.updateSplashLoaderProgress(20);
            
            JAVA_COMPILER_UTIL = new JavaCompilerUtil(FILE_MANAGER);
            splashScreen.updateSplashLoaderProgress(40);
            
            JAVA_TEST_RUNNER = new JavaTestRunner();
            splashScreen.updateSplashLoaderProgress(60);
            
            PDF_GENERATOR = new PDFGenerator();
            splashScreen.updateSplashLoaderProgress(80);
            
            JAVA_JUDGE = new JavaJudge(FILE_MANAGER, JAVA_COMPILER_UTIL, JAVA_TEST_RUNNER, PDF_GENERATOR);
            splashScreen.updateSplashLoaderProgress(100);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }


        // After loading completes, close the splash screen and show the main UI
        splashScreen.closeSplashScreen();

        // Now create and display the main UI
        String STUDENT_BULK_SUBMISSION_PATH = null;
        String TEST_BULK_SUBMISSION_PATH = null;
        String OUTPUT_PATH = null;

        SwingUtilities.invokeLater(() -> {
            Screen mainScreen = new DashScreen(configStyle, STUDENT_BULK_SUBMISSION_PATH, TEST_BULK_SUBMISSION_PATH, OUTPUT_PATH);
            mainScreen.display();

            System.out.println(STUDENT_BULK_SUBMISSION_PATH);
            System.out.println(TEST_BULK_SUBMISSION_PATH);
            System.out.println(OUTPUT_PATH);
        });
    }
}