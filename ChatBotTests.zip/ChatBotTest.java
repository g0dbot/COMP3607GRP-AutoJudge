import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class ChatBotTest {
    @TestFactory
    List<DynamicTest> generateChatBotTests() throws Exception {
        List<DynamicTest> dynamicTests = new ArrayList<>();
        
        Class<?> chatBotClass = Class.forName("ChatBot");
        Object chatBotInstance = chatBotClass.getDeclaredConstructor().newInstance();

        Method getChatBotNameMethod = chatBotClass.getMethod("getChatBotName");
        dynamicTests.add(DynamicTest.dynamicTest("Test getChatBotName", () -> {
            String result = (String) getChatBotNameMethod.invoke(chatBotInstance);
            try {
                assertEquals("ChatGPT-3.5", result);
            } catch (AssertionError e) {
                throw new AssertionError("Expected ChatGPT-3.5, but got " + result);
            }
        }));

        Method getNumResponsesGeneratedMethod = chatBotClass.getMethod("getNumResponsesGenerated");
        dynamicTests.add(DynamicTest.dynamicTest("Test getNumResponsesGenerated", () -> {
        
                int result = (int) getNumResponsesGeneratedMethod.invoke(chatBotInstance);
                try {
                    assertEquals(0, result);
                } catch (AssertionError e) {
                    throw new AssertionError("Expected 0 responses generated, but got " + result);
                }
            }
        ));

        Method promptMethod = chatBotClass.getMethod("prompt", String.class);
        dynamicTests.add(DynamicTest.dynamicTest("Test prompt", () -> {
            String result = (String) promptMethod.invoke(chatBotInstance, "test message");
            try {
                assertTrue(result.startsWith("(Message# 1) Response from ChatGPT-3.5 >>"));
            } catch (AssertionError e) {
                throw new AssertionError("Expected response to start with '(Message# 1) Response from ChatGPT-3.5 >>', but got: " + result);
            }
        }));

        Method getTotalNumResponsesGeneratedMethod = chatBotClass.getMethod("getTotalNumResponsesGenerated");
        dynamicTests.add(DynamicTest.dynamicTest("Test getTotalNumResponsesGenerated", () -> {
            int result = (int) getTotalNumResponsesGeneratedMethod.invoke(null);
            try {
                assertEquals(0, result);
            } catch (AssertionError e) {
                throw new AssertionError("Expected total responses generated to be 0, but got " + result);
            }}));

        Method getTotalNumMessagesRemainingMethod = chatBotClass.getMethod("getTotalNumMessagesRemaining");
        dynamicTests.add(DynamicTest.dynamicTest("Test getTotalNumMessagesRemaining", () -> {
            int result = (int) getTotalNumMessagesRemainingMethod.invoke(null);
            try {
                assertEquals(10, result);
            } catch (AssertionError e) {
                throw new AssertionError("Expected 10 messages remaining, but got " + result);
            }
        }));

        Method limitReachedMethod = chatBotClass.getMethod("limitReached");
        dynamicTests.add(DynamicTest.dynamicTest("Test limitReached", () -> {
            boolean result = (boolean) limitReachedMethod.invoke(null);
            try {
                assertFalse(result);
            } catch (AssertionError e) {
                throw new AssertionError("Expected limit not reached, but got limit reached");
            }
        }));

        return dynamicTests;
    
}
}