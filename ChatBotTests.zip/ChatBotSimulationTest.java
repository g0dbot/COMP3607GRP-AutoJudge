import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class ChatBotSimulationTest {
    @TestFactory
    List<DynamicTest> generateSimulationTests() throws Exception {
        List<DynamicTest> dynamicTests = new ArrayList<>();
        
        Class<?> simulationClass = Class.forName("ChatBotSimulation");
        Method mainMethod = simulationClass.getMethod("main", String[].class);

        dynamicTests.add(DynamicTest.dynamicTest("Test MainMethod Sequence", () -> {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            PrintStream originalOut = System.out;
            System.setOut(new PrintStream(outputStream));

            try {
                mainMethod.invoke(null, (Object) new String[0]);
                String output = outputStream.toString();

                try {
                    assertTrue(output.startsWith("Hello World!"));
                } catch (AssertionError e) {
                    System.out.println("Output did not start with 'Hello World!'");
                    throw new AssertionError("test failed");
                }
                
                try {
                    assertTrue(output.contains("Your ChatBots"));
                } catch (AssertionError e) {
                    System.out.println("Output did not contain 'Your ChatBots'");
                    throw new AssertionError("test failed");
                }
                
                int messageCount = countOccurrences(output, "Response from");
                try {
                    assertTrue(messageCount > 0 && messageCount <= 15);
                } catch (AssertionError e) {
                    System.out.println("Message count " + messageCount + " not between 1 and 15");
                    throw new AssertionError("test failed");
                }
                
                String[] requiredBots = {
                    "ChatGPT-3.5", "LLaMa", "Mistral7B", 
                    "Bard", "Claude", "Solar"
                };
                
                for (String bot : requiredBots) {
                    try {
                        assertTrue(output.contains(bot));
                    } catch (AssertionError e) {
                        System.out.println("Output missing required bot: " + bot);
                        throw new AssertionError("test failed");
                    }
                }

            } catch (Exception e) {
                System.out.println("Method invocation failed: " + e.getMessage());
                throw new AssertionError("test failed due to exception");
            } finally {
                System.setOut(originalOut);
            }
        }));

        return dynamicTests;
    }

    private int countOccurrences(String text, String search) {
        return (text.length() - text.replace(search, "").length()) / search.length();
    }
}
