import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class ChatBotGeneratorTest {
    @TestFactory
    List<DynamicTest> generateLLMTests() throws Exception {
        List<DynamicTest> dynamicTests = new ArrayList<>();
        
        Class<?> chatBotGeneratorClass = Class.forName("ChatBotGenerator");
        Method generateChatBotLLMMethod = chatBotGeneratorClass.getMethod("generateChatBotLLM", int.class);

        int[] codes = {0, 1, 2, 3, 4, 5};
        String[] expectedResults = {
            "ChatGPT-3.5", "LLaMa", "Mistral7B", "Bard", "Claude", "Solar"
        };

        for (int i = 0; i < codes.length; i++) {
            final int code = codes[i];
            final String expected = expectedResults[i];

            dynamicTests.add(DynamicTest.dynamicTest("Test generateChatBotLLM - " + expected, () -> {
                try {
                    String result = (String) generateChatBotLLMMethod.invoke(null, code);
                    try {
                        assertEquals(expected, result);
                    } catch (AssertionError e) {
                        System.out.println("Expected " + expected + " for code " + code + ", but got " + result);
                        throw new AssertionError("test failed");
                    }
                } catch (Exception e) {
                    System.out.println("Method invocation failed: " + e.getMessage());
                    throw new AssertionError("test failed due to exception");
                }
            }));
        }

        return dynamicTests;
    }
}
