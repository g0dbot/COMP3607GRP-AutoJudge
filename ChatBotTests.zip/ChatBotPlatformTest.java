import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class ChatBotPlatformTest {
    @TestFactory
    List<DynamicTest> generatePlatformTests() throws Exception {
        List<DynamicTest> dynamicTests = new ArrayList<>();
        
        Class<?> chatBotPlatformClass = Class.forName("ChatBotPlatform");
        Object chatBotPlatformInstance = chatBotPlatformClass.getDeclaredConstructor().newInstance();

        Method addChatBotMethod = chatBotPlatformClass.getMethod("addChatBot", int.class);
        dynamicTests.add(DynamicTest.dynamicTest("Test addChatBot", () -> {
            try {
                boolean result = (boolean) addChatBotMethod.invoke(chatBotPlatformInstance, 1);
                try {
                    assertTrue(result);
                } catch (AssertionError e) {
                    System.out.println("Expected addChatBot to return true, but got false");
                    throw new AssertionError("test failed");
                }
            } catch (Exception e) {
                System.out.println("Method invocation failed: " + e.getMessage());
                throw new AssertionError("test failed due to exception");
            }
        }));

        Method getChatBotListMethod = chatBotPlatformClass.getMethod("getChatBotList");
        dynamicTests.add(DynamicTest.dynamicTest("Test getChatBotList empty", () -> {
            try {
                String result = (String) getChatBotListMethod.invoke(chatBotPlatformInstance);
                try {
                    assertEquals("", result);
                } catch (AssertionError e) {
                    System.out.println("Expected empty string, but got: " + result);
                    throw new AssertionError("test failed");
                }
            } catch (Exception e) {
                System.out.println("Method invocation failed: " + e.getMessage());
                throw new AssertionError("test failed due to exception");
            }
        }));

        Method interactWithBotMethod = chatBotPlatformClass.getMethod("interactWithBot", int.class, String.class);
        dynamicTests.add(DynamicTest.dynamicTest("Test interactWithBot invalid number", () -> {
            try {
                String result = (String) interactWithBotMethod.invoke(chatBotPlatformInstance, 7, "test message");
                try {
                    assertEquals("Incorrect Bot Number (7) Selected. Try again", result);
                } catch (AssertionError e) {
                    System.out.println("Expected 'Incorrect Bot Number (7) Selected. Try again', but got: " + result);
                    throw new AssertionError("test failed");
                }
            } catch (Exception e) {
                System.out.println("Method invocation failed: " + e.getMessage());
                throw new AssertionError("test failed due to exception");
            }
        }));

        return dynamicTests;
    }
}
